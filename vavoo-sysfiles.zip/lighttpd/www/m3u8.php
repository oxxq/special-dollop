<?php
    $e = shell_exec("/data/data/com.termux/files/usr/bin/python2 /data/data/com.termux/files/home/lighttpd/www/playlist.py m3u8");
    echo "$e";
?>
