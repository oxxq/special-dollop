<?php
    $e = shell_exec("/data/data/com.termux/files/usr/bin/bash /data/data/com.termux/files/home/epg.sh epg");
    echo "$e";
?>
